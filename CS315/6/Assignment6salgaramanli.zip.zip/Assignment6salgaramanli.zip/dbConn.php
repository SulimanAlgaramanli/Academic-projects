<?php // dbConn.php

$hn = 'localhost';

$db = 'Grocery';

$un = 'root';

$pw = '';

?>